export type Message = {
  id: string;
  sender: "user" | "ai";
  message: string;
  createdAt: string;
};

export type Conversation = {
  id: string;
  title: string;
  createdAt: string;
  updatedAt: string;
  messages: Message[];
};