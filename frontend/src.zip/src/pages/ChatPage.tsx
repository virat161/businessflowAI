import { useEffect, useState } from "react";
import Sidebar from "../components/chat/Sidebar";
import ChatHeader from "../components/chat/ChatHeader";
import ChatMessages from "../components/chat/ChatMessages";
import ChatInput from "../components/chat/ChatInput";

import type { Conversation } from "../types/chat";
import {
  loadConversations,
  saveConversations,
} from "../services/chatStorage";

export default function ChatPage() {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeConversationId, setActiveConversationId] = useState<
    string | null
  >(null);
  const [isTyping, setIsTyping] = useState(false);

  /**
   * Load conversations from LocalStorage
   */
  useEffect(() => {
    const storedConversations = loadConversations();

    if (storedConversations.length > 0) {
      setConversations(storedConversations);
      setActiveConversationId(storedConversations[0].id);
    } else {
      const defaultConversation: Conversation = {
        id: crypto.randomUUID(),
        title: "New Chat",
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        messages: [],
      };

      setConversations([defaultConversation]);
      setActiveConversationId(defaultConversation.id);
    }
  }, []);

  /**
   * Save conversations automatically
   */
  useEffect(() => {
    if (conversations.length > 0) {
      saveConversations(conversations);
    }
  }, [conversations]);

  const activeConversation = conversations.find(
    (chat) => chat.id === activeConversationId
  );

  const handleNewChat = () => {
    const newConversation: Conversation = {
      id: crypto.randomUUID(),
      title: `New Chat ${conversations.length + 1}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      messages: [],
    };

    setConversations((prev) => [...prev, newConversation]);
    setActiveConversationId(newConversation.id);
  };

  const handleSendMessage = (message: string) => {
    if (!message.trim() || !activeConversationId) return;

    // Lock current conversation
    const conversationId = activeConversationId;

    setConversations((prev) =>
      prev.map((chat) => {
        if (chat.id !== conversationId) return chat;

        let updatedTitle = chat.title;

        if (chat.title.startsWith("New Chat")) {
          updatedTitle =
            message.length > 30
              ? message.substring(0, 30) + "..."
              : message;
        }

        return {
          ...chat,
          title: updatedTitle,
          updatedAt: new Date().toISOString(),
          messages: [
            ...chat.messages,
            {
              id: crypto.randomUUID(),
              sender: "user",
              message,
              createdAt: new Date().toISOString(),
            },
          ],
        };
      })
    );

    setIsTyping(true);

    setTimeout(() => {
      setConversations((prev) =>
        prev.map((chat) =>
          chat.id === conversationId
            ? {
                ...chat,
                updatedAt: new Date().toISOString(),
                messages: [
                  ...chat.messages,
                  {
                    id: crypto.randomUUID(),
                    sender: "ai",
                    message:
                      "This is a fake AI response. Later we'll replace this with Gemini AI.",
                    createdAt: new Date().toISOString(),
                  },
                ],
              }
            : chat
        )
      );

      setIsTyping(false);
    }, 1500);
  };

  if (!activeConversation) {
    return (
      <div className="flex h-screen items-center justify-center">
        Loading...
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-slate-100">
      <Sidebar
        conversations={conversations}
        activeConversationId={activeConversationId}
        onSelectConversation={setActiveConversationId}
        onNewChat={handleNewChat}
      />

      <div className="flex flex-1 flex-col">
        <ChatHeader />

        <ChatMessages
          messages={activeConversation.messages}
          isTyping={isTyping}
          onSuggestionClick={handleSendMessage}
        />

        <ChatInput onSendMessage={handleSendMessage} />
      </div>
    </div>
  );
}