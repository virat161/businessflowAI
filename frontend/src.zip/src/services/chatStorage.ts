import { Conversation } from "../types/chat";

const STORAGE_KEY = "businessflow-conversations";

/**
 * Load all conversations from LocalStorage
 */
export function loadConversations(): Conversation[] {
  try {
    const storedData = localStorage.getItem(STORAGE_KEY);

    if (!storedData) {
      return [];
    }

    return JSON.parse(storedData);
  } catch (error) {
    console.error("Failed to load conversations:", error);
    return [];
  }
}

/**
 * Save all conversations to LocalStorage
 */
export function saveConversations(
  conversations: Conversation[]
): void {
  try {
    localStorage.setItem(
      STORAGE_KEY,
      JSON.stringify(conversations)
    );
  } catch (error) {
    console.error("Failed to save conversations:", error);
  }
}

/**
 * Clear all conversations
 */
export function clearConversations(): void {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch (error) {
    console.error("Failed to clear conversations:", error);
  }
}